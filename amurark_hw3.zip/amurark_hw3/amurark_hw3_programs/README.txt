=========README===========
1. The 'ankitmurarka_main.txt' file is calling all the other files. This contains the main function.
2. The result file is to return Results for dynamic programming.
3. The files ankitmurarka_dynamic, ankitmurarka_recursive and ankitmurarka_memoized.txt are the 3 files containing algorithms for matrix multiplication.
=========END===============
